
SET @targetCid = "換上指定Hall的CidS";
SET @currency = "NZD2";


SET @p1 = "26,25,24,23";
SET @dp1 = "25";
SET @p3 = "27,26,25,24";
SET @dp3 = "26";
SET @p5 = "27,26,25";
SET @dp5 = "26";
SET @p9 = "28,27,26,25";
SET @dp9 = "27";
SET @p10 = "28,27,26";
SET @dp10 = "27";
SET @p15 = "29,28,27,26";
SET @dp15 = "28";
SET @p20 = "29,28,27,26";
SET @dp20 = "28";
SET @p25 = "29,28,27";
SET @dp25 = "28";
SET @p30 = "29,28,27";
SET @dp30 = "28";
SET @p40 = "29,28,27";
SET @dp40 = "28";
SET @p50 = "29,28";
SET @dp50 = "28";
SET @p88 = "29,28";
SET @dp88 = "28";

INSERT INTO game.game_denom_setting
SELECT cId, gameId, currency, pb, dp ,null,0 FROM
(
SELECT gs.cId, gs.gameId, @currency as currency,
CASE 
WHEN g.minbet = 1 THEN @p1 
WHEN g.minbet = 3 THEN @p3 
WHEN g.minbet = 5 THEN @p5 
WHEN g.minbet = 9 THEN @p9 
WHEN g.minbet = 10 THEN @p10 
WHEN g.minbet = 15 THEN @p15
WHEN g.minbet = 20 THEN @p20
WHEN g.minbet = 25 THEN @p25 
WHEN g.minbet = 30 THEN @p30 
WHEN g.minbet = 40 THEN @p40 
WHEN g.minbet = 50 THEN @p50 
WHEN g.minbet = 88 THEN @p88 
ELSE @p1 END as pb,

CASE
WHEN g.minbet = 1 THEN @dp1 
WHEN g.minbet = 3 THEN @dp3 
WHEN g.minbet = 5 THEN @dp5 
WHEN g.minbet = 9 THEN @dp9 
WHEN g.minbet = 10 THEN @dp10
WHEN g.minbet = 15 THEN @dp15
WHEN g.minbet = 20 THEN @dp20
WHEN g.minbet = 25 THEN @dp25 
WHEN g.minbet = 30 THEN @dp30 
WHEN g.minbet = 40 THEN @dp40 
WHEN g.minbet = 50 THEN @dp50 
WHEN g.minbet = 88 THEN @dp88  
ELSE @dp1 END as dp,

null, 
0
FROM game.game_setting gs
JOIN game.games g 
ON g.gameId = gs.gameId
WHERE cid = @targetCid
) t
on duplicate key update Denom = t.pb, DefaultDenomId = t.dp;